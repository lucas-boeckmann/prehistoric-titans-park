function Play() {
    window.location = "./Park/park.html"
  }